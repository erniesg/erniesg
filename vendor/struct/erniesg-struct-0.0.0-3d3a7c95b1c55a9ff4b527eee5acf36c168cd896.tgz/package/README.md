# @erniesg/struct

`@erniesg/struct` is the source-neutral semantic-document and deterministic
reflowable-publication package. It owns `StructDocument` codecs, stable IDs and
relationships, reading order, source-neutral diagnostics/recovery facts,
semantic receipts, and deterministic XHTML/reflowable EPUB output. It does not
own acquisition, PDF/DOCX/URL extraction, private reconstruction,
source-specific recovery wording, editorial decisions, approvals, release
records, application UI, providers, or public routes. Ernie.SG owns its
source-specific acquisition, reconstruction, editorial, and public-delivery
responsibilities. Credentials and deployment authority stay at each owning
application/adapter boundary; Struct never receives them. Aether may consume a
verified, pinned bundle but owns visual composition and derivatives. Rucksack
remains generic orchestration and owns none of these domain models.

## State and evidence

**Current runtime baseline** (the cutover candidate head; the exact commit is
recorded in the release packet; the previous baseline
`e9ea4b8be0b92e6f35262da572a855216286716c` is superseded by it; that
documentation change touched no runtime code):
this is a private `0.0.0` package with source-neutral document/codecs/IDs/
recovery/XHTML/EPUB capabilities plus a current embedded-only public
`./bundle` facade that exports all seven runtime names:
`STRUCT_BUNDLE_LIMITS_PROFILE`, `STRUCT_BUNDLE_LIMITS_PROFILE_VERSION`,
`StructBundleError`, `createStructBundle`, `decodeStructBundle`,
`encodeStructBundle`, `verifyStructBundle`. The facade returns direct
handles and throws/rejects the documented structured `StructBundleError`;
decode is always async (`Promise<VerifiedStructBundle>`); encode returns
`Uint8Array`. When given the full flat resolver configuration (`resolverExecutor`,
`resolverPolicy`, `resolverBudget`, `resolverHostSupervisor`, optional
`resolverSignal`), `decodeStructBundle` resolves external assets through the
private external core; without it, external payloads fail closed with
`UNRESOLVED` (`stage: 'assets'`, `code: 'UNRESOLVED'`). The isolated
resolver/executor protocol and its execution driver are implemented privately
in-tree but are not public surface. The public external-bytes decode seam
(`decodeStructBundle`) is part of the current surface; the real-host
conformance harness is implemented in-tree as test-only evidence and is not
public surface; full S-03/S-04 acceptance remains separately pending.
There is no exact-pinned external consumer, registry release, or publish
workflow.

The current head adds exactly one additive, optional document field:
`StructInline` gains a boolean `code` flag that marks a character range as
verbatim source code and renders as the HTML `<code>` element in the XHTML
renderer and, through the same XHTML path, in the EPUB content document. A
document that omits the flag decodes and renders exactly as before, so
document schema `0.2.0` is unchanged and needs no version bump. The change
adds no runtime export, no export path, and no `API_MANIFEST.json` entry.

**Documented target** is the ADR-0001 contract in [CONTRACT.md](./CONTRACT.md):
a source-neutral package with a fail-closed verified `StructBundle` boundary.
The current embedded facade (`createStructBundle`, `verifyStructBundle`,
direct-handle return, async `decodeStructBundle`, byte-returning
`encodeStructBundle`, structured `StructBundleError`, and the frozen
versioned limits profile) is implemented at the current runtime baseline; the
isolated resolver/executor protocol and its execution driver are implemented
privately in-tree but are not public surface. The public external-bytes
decode seam (`decodeStructBundle`) is part of the current surface; the
real-host conformance harness is implemented in-tree as test-only evidence and
is not public surface; full S-03/S-04 acceptance remains separately pending.

**Stage status:** Stage 1 is implemented and unreleased; it does not complete
S-03, S-04, or E-02, and it does not activate a release, route, or writer.

**Implemented, unreleased** means exact code and local evidence exist, but not
a package or application release. **Released** requires an exact registry
version, immutable artifact digest, install proof, and release record. A
configuration change, branch, documentation change, or passing local test is
not release evidence.

## Current usage

Use only the currently exported API paths recorded in [API.md](./API.md). The
EPUB builder is asynchronous and must be awaited:

```ts
import {
  decodeCompatibleStructDocument,
  encodeStructDocument,
} from '@erniesg/struct'
import { renderPublicationXhtml } from '@erniesg/struct/renderers/xhtml'
import { buildStructEpub } from '@erniesg/struct/renderers/epub'

const document = decodeCompatibleStructDocument(input)
const canonicalJson = encodeStructDocument(document)
const xhtml = renderPublicationXhtml(document)
const epub = await buildStructEpub(document)
```

The root facade contains document types and core codecs only. Do not import
private `src/**` files in consumers; see [API.md](./API.md) for the explicit
subpaths and the bounded deprecated-alias window.

## Package contract and migration

[CONTRACT.md](./CONTRACT.md) is the normative package contract; it links to
ADR-0001 for the complete planned Bundle protocol. [MIGRATION.md](./MIGRATION.md)
records source provenance and the staged consumer migration. These contract
documents ship in the package file list, so this documentation correction
requires a fresh packed artifact, digest, and installed-consumer proof before
any application repin; no application repin is part of this change. The
bootstrap package remains private and has no publishing workflow.
